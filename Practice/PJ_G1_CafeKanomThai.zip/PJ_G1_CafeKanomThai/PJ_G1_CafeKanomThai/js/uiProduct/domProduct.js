import products from "../products.js";

const product = document.querySelector("#p");

let count = 0;
const CountInCart = document.getElementById("count");
CountInCart.textContent = count;

// const cookiesBtn = document.createElement('button');
// cookiesBtn.className = 'shadow-lg my-2  ml-4 mr-8 py-2 px-4 bg-white-500 rounded-full font-medium hover:bg-black hover:text-white active:border-blue-700'
// cookiesBtn.innerHTML = "Cookies"
// cookiesBtn.setAttribute('id','cookieTest');
// footerDetail.appendChild(cookiesBtn);

// class CookieUtil {
//     static get(name) {
//       console.log(`all cookies: ${document.cookie}`);
//       let cookieName = `${encodeURIComponent(name)}=`,
//         cookieStart = document.cookie.indexOf(cookieName),
//         cookieValue = null;
//       console.log(`cookieName = ${cookieName}`);
//       console.log(`cookieStart = ${cookieStart}`);
  
//       if (cookieStart > -1) {
//         let cookieEnd = document.cookie.indexOf(';', cookieStart);
//         console.log(`cookieEnd = ${cookieEnd}`);
//         if (cookieEnd == -1) {
//           cookieEnd = document.cookie.length;
//         }
//         cookieValue = decodeURIComponent(
//           document.cookie.substring(cookieStart + cookieName.length, cookieEnd)
//         );
//         console.log(`cookieValue = ${cookieValue}`);
//       }
  
//       return cookieValue;
//     }
  
//     static set(name, value, expires) {
//       let cookieText = `${encodeURIComponent(name)}=${encodeURIComponent(value)}`;
  
//       if (expires instanceof Date) {
//         cookieText += `; expires=${expires.toUTCString()}`;
//         // cookieText += `; expires=${expires}`;
//       }
  
//       console.log(`cookieText = ${cookieText}`);
//       document.cookie = cookieText;
//     }
  
//     static unset(name) {
//       CookieUtil.set(name, '', new Date(0));
//     }
//   }
  
//   const encodeKey = encodeURIComponent('yourFont');
//   const encodeValue = encodeURIComponent('12 pt');
//   // let expireDate = new Date(Date.now() + 86400e3);
//   let expireDate = new Date('2021-11-15');
  
//   expireDate.toUTCString();
//   // expireDate = new Date().toUTCString();
//   // document.cookie = encodeKey + '=' + encodeValue + ';' + 'expires=' + expireDate;
//   document.cookie = encodeKey + '=' + encodeValue + ';' + 'max-age=86400';
//   // document.cookie = 'myBgColor=blue;path=/';


for(let items of products){
    console.log(items);
    let divEle = document.createElement("div");
    divEle.className = "w-1/1 rounded-lg shadow-xl bg-white ";
    divEle.setAttribute("id",items.name);
    divEle.setAttribute("name",items.thai);
    divEle.setAttribute("pieces",items.pieces)
    let ImgEle = appendImgProduct(items);
    let NameEle = appendNameProduct(items);
    let DetailEle = appendDetailProduct(items);
    
    divEle.appendChild(ImgEle);
    divEle.appendChild(NameEle);
    divEle.appendChild(DetailEle);
    product.appendChild(divEle);
}

function appendImgProduct(item){
    let imgEle = document.createElement("img");
    imgEle.className = "rounded-t-lg h-60 w-full object-cover";
    imgEle.src = item.srcimg;
    imgEle.alt = item.alt;
    return imgEle;
}

function appendNameProduct(item){
    let divProduct = document.createElement("div");
    let headerEle = document.createElement("header");
    headerEle.className = "text-xl font-extrabold p-4"
    headerEle.textContent = item.name;
    let divDetail = document.createElement("div");
    divDetail.className = "px-5";
    let pEle = document.createElement("p");
    pEle.className = "text-gray-500 px-4";
    // pEle.textContent = item.thai; // ไว้ใส่คำอธิบาย

    divDetail.appendChild(pEle);
    divProduct.appendChild(headerEle);
    divProduct.appendChild(divDetail);
    return divProduct;
}

function appendDetailProduct(item){
    let footerDetail = document.createElement("div");
    footerDetail.className = "py-3 px-8 text-gray-500 grid grid-cols-2 gap-6"

    let divPrice = document.createElement("p");
    divPrice.className = "text-teal-500 font-semibold text-lg font-poppins text-left"
    divPrice.textContent = "ราคา : " + item.price + "฿";

    //add pieces
    let divPieces = document.createElement("p");
    divPieces.className = "text-teal-500 font-semibold text-lg font-poppins text-right"
    divPieces.textContent = "pieces : " + item.pieces ;

    let btnEle = document.createElement("button");
    btnEle.className = "py-2 px-4  bg-green-500 rounded-lg text-white font-semibold hover:bg-green-600 ";
    btnEle.textContent = "Add to Cart";

    btnEle.setAttribute("id" , item.tag);
    btnEle.setAttribute("name" , "product");
    btnEle.addEventListener("click" , ()=>{
      alert(`add ${item.name} to cart`);
      count++;
      CountInCart.textContent = count;

    //   document.cookie="product 1 +" +btnEle+ "; max-age=" +60*60*24*10;
    })

    footerDetail.appendChild(divPrice);
    footerDetail.appendChild(divPieces);
    footerDetail.appendChild(btnEle);
    return footerDetail;


    
    
}